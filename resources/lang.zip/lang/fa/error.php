<?php

return [
    'page_not_found'=>'صفحه مورد نظر پیدا نشد',
];
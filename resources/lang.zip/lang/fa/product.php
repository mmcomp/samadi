<?php

return [
    'product_price_purchase'=>'قیمت محصول و خرید',
    'tooman'=>'دلارآمریکا',
    'purchase_product'=>'خرید محصول',
    'name_star_customer'=>'نام و امتیاز طراح',
    'product_name'=>'نام محصول',
    'product_description'=>'ویژگی های محصول',
    'customers_also_buy'=>'خریداران این محصول، محصولات زیر را هم خریده‌اند',
    'new_products'=>'جدیدترین محصولات',
    'category'=>'دسته',
    'categories'=>'دسته بندی ها',
    'download'=>'دریاف',
    'similar_products'=>'محصولات مشابه',
];
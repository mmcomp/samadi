<?php

return [
    'page_not_found'=>'Page Not Found!',
];
<?php

return [
    'product_price_purchase'=>'Product Price & Purchase',
    'tooman'=>'USD',
    'purchase_product'=>'Purchase',
    'name_star_customer'=>'Name & Score of the Designer',
    'product_name'=>'Product Name',
    'product_description'=>'Product Description',
    'customers_also_buy'=>'Customers also purchased these products',
    'new_products'=>'New Products',
    'category'=>'Category',
    'categories'=>'Categories',
    'download'=>'Download',
    'similar_products'=>'Similar Products',
];